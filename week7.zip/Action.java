true if damage
false if it's damage and the buff

   if it's true, then game would also access 